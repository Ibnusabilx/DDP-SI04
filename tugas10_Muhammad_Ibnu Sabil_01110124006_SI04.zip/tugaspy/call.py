print('==================')

import bangun_datar

print('## Perhitungan Persegi ##')

bangun_datar.l_persegi(10)

import bangun_datar

print('## Perhitungan Segitiga')

bangun_datar.l_segitiga(5,8)

import bangun_datar

print('## Perhitungan Jajar Genjang ##')

bangun_datar.l_jajar_genjang(3,9)

import bangun_datar

print('## Perhitungan Persegi Panjang ##')

bangun_datar.l_persegi_panjang(3,9)

import bangun_datar

print('## Perhitungan Belah Ketupat ##')

bangun_datar.l_belah_ketupat(4,9)

import bangun_datar

print('## Perhitungan Trapesium ##')

bangun_datar.l_trapesium(3, 4, 9)


import bangun_datar

print('## Perhitungan Layang-layang ##')

bangun_datar.l_layang_layang(3, 3)

import bangun_datar

print('## Perhitungan Belah Ketupat ##')

bangun_datar.l_belah_ketupat(3, 5)

print('==================')

import hitung

hitung.tambah(3, 4)

import hitung

hitung.kurang(10, 8)

import hitung

hitung.kali(1, 3)

import hitung

hitung.bagi(10, 5)

import hitung

hitung.pangkat(1, 6)

print('==================')

import bangun_ruang

bangun_ruang.luas_balok(9, 5, 7)

import bangun_ruang

bangun_ruang.luas_bola(4)

import bangun_ruang

bangun_ruang.luas_kerucut(3, 7)

import bangun_ruang

bangun_ruang.luas_kubus(5)



